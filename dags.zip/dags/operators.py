from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.bash import BashOperator
from airflow.utils.dates import days_ago

def hello():
    print("Hello from PythonOperator!")

with DAG(
    dag_id='operators_demo',
    start_date=days_ago(1),
    schedule_interval=None,
    catchup=False,
) as dag:
    py_task = PythonOperator(
        task_id='python_task',
        python_callable=hello
    )

    bash_task = BashOperator(
        task_id='bash_task',
        bash_command='echo "Hello from BashOperator!"'
    )

    py_task >> bash_task