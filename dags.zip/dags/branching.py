from airflow import DAG
from airflow.operators.python import BranchPythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.utils.dates import days_ago
import random

def choose_branch():
    return 'even_branch' if random.randint(1, 10) % 2 == 0 else 'odd_branch'

with DAG(
    dag_id='branching_demo',
    start_date=days_ago(1),
    schedule_interval=None,
    catchup=False,
) as dag:
    branch = BranchPythonOperator(
        task_id='branching',
        python_callable=choose_branch
    )

    even_branch = DummyOperator(task_id='even_branch')
    odd_branch = DummyOperator(task_id='odd_branch')
    join = DummyOperator(task_id='join', trigger_rule='none_failed_or_skipped')

    branch >> [even_branch, odd_branch] >> join