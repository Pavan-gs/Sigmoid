from airflow import DAG
from airflow.operators.dummy import DummyOperator
from airflow.utils.dates import days_ago
from airflow.utils.trigger_rule import TriggerRule

with DAG(
    dag_id='trigger_rule_demo',
    start_date=days_ago(1),
    schedule_interval=None,
    catchup=False,
) as dag:
    t1 = DummyOperator(task_id='task_success')
    t2 = DummyOperator(task_id='task_skipped')
    final = DummyOperator(task_id='final_task', trigger_rule=TriggerRule.ONE_SUCCESS)

    [t1, t2] >> final