from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.utils.dates import days_ago

def greet_user(**context):
    name = context['dag_run'].conf.get('name', 'Guest')
    print(f"Hello, {name}!")

with DAG(
    dag_id='manual_trigger_demo',
    start_date=days_ago(1),
    schedule_interval=None,
    catchup=False,
) as dag:
    greet = PythonOperator(
        task_id='greet_user',
        python_callable=greet_user,
        provide_context=True
    )