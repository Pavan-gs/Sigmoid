from airflow import DAG
from airflow.operators.dummy import DummyOperator
from airflow.utils.dates import days_ago

with DAG(
    dag_id='dependencies_demo',
    start_date=days_ago(1),
    schedule_interval=None,
    catchup=False,
) as dag:
    task1 = DummyOperator(task_id='task1')
    task2 = DummyOperator(task_id='task2')
    task3 = DummyOperator(task_id='task3')

    task1 >> task2 >> task3