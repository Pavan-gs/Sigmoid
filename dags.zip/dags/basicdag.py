from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime

# Define the Python function to be run by the PythonOperator
def print_hello():
    print("Hello, Airflow!")

# Create the DAG object
dag = DAG(
    'basic_hello_dag',  # Unique name for this DAG
    description='A simple hello world DAG',
    schedule_interval='* * * * *',  # This means it will run every minute
    start_date=datetime(2025, 4, 17),
    catchup=False  # If set to False, it won’t run for past missed intervals
)

# Create the task (PythonOperator) that will call the print_hello function
task1 = PythonOperator(
    task_id='print_hello_task',
    python_callable=print_hello,
    dag=dag
)

from airflow.operators.bash import BashOperator

# Add a new task that runs a bash command
task2 = BashOperator(
    task_id='print_date_task',
    bash_command='date',  # This will print the current date and time
    dag=dag
)

# Define the task dependencies
task1 >> task2  # task1 will run before task2

# Define a task that will intentionally fail to test retries
def fail_task():
    raise Exception("This is a failed task!")

# Create the task that will fail
fail_task_operator = PythonOperator(
    task_id='fail_task',
    python_callable=fail_task,
    retries=3,  # Retry up to 3 times if the task fails
    retry_delay=timedelta(seconds=5),  # Retry after 5 seconds
    dag=dag
)

# Update task dependencies
task1 >> fail_task_operator >> task2

from airflow.operators.python import BranchPythonOperator

def choose_branch(**kwargs):
    if kwargs['execution_date'].minute % 2 == 0:
        return 'even_branch'
    else:
        return 'odd_branch'

# Create the branching task
branch_task = BranchPythonOperator(
    task_id='branch_task',
    python_callable=choose_branch,
    provide_context=True,  # To pass execution context
    dag=dag
)

# Define two branches
even_branch = DummyOperator(
    task_id='even_branch',
    dag=dag
)

odd_branch = DummyOperator(
    task_id='odd_branch',
    dag=dag
)

# Define dependencies
task1 >> branch_task
branch_task >> even_branch
branch_task >> odd_branch

