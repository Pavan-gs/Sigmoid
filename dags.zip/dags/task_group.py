from airflow import DAG
from airflow.operators.dummy import DummyOperator
from airflow.utils.task_group import TaskGroup
from airflow.utils.dates import days_ago

with DAG(
    dag_id='taskgroup_demo',
    start_date=days_ago(1),
    schedule_interval=None,
    catchup=False,
) as dag:
    start = DummyOperator(task_id='start')

    with TaskGroup("processing_tasks") as tg:
        t1 = DummyOperator(task_id='load')
        t2 = DummyOperator(task_id='process')
        t3 = DummyOperator(task_id='save')
        t1 >> t2 >> t3

    end = DummyOperator(task_id='end')
    start >> tg >> end