from airflow import DAG
from airflow.operators.dummy import DummyOperator
from airflow.utils.dates import days_ago

default_args = {'owner': 'airflow'}

with DAG(
    dag_id='basic_dag',
    default_args=default_args,
    start_date=days_ago(1),
    schedule_interval=None,
    catchup=False,
) as dag:
    start = DummyOperator(task_id='start')
    middle = DummyOperator(task_id='middle')
    end = DummyOperator(task_id='end')

    start >> middle >> end