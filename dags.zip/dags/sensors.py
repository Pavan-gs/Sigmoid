from airflow import DAG
from airflow.sensors.filesystem import FileSensor
from airflow.operators.dummy import DummyOperator
from airflow.utils.dates import days_ago

with DAG(
    dag_id='sensor_demo',
    start_date=days_ago(1),
    schedule_interval=None,
    catchup=False,
) as dag:
    wait_file = FileSensor(
        task_id='wait_for_file',
        filepath='/tmp/trigger.txt',
        poke_interval=5,
        timeout=60
    )

    proceed = DummyOperator(task_id='proceed')
    wait_file >> proceed