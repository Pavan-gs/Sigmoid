from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.email import EmailOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
from datetime import datetime
import pandas as pd

def extract_data():
    pg_hook = PostgresHook(postgres_conn_id='my_postgres_conn')
    df = pg_hook.get_pandas_df(sql='SELECT * FROM sales')
    df.to_csv('/tmp/sales_report.csv', index=False)

with DAG(
    dag_id='daily_sales_report',
    start_date=datetime(2024, 1, 1),
    schedule_interval='@daily',
    catchup=False,
    tags=['reporting']
) as dag:

    extract_task = PythonOperator(
        task_id='extract_sales_data',
        python_callable=extract_data
    )

    email_task = EmailOperator(
        task_id='send_email',
        to='report@company.com',
        subject='Daily Sales Report',
        html_content='Please find attached the daily sales report.',
        files=['/tmp/sales_report.csv']
    )

    extract_task >> email_task
