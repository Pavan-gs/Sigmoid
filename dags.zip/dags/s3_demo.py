
from airflow import DAG
from airflow.providers.amazon.aws.operators.s3 import S3CreateBucketOperator
from datetime import datetime

with DAG(dag_id="s3_demo",
         start_date=datetime(2024, 1, 1),
         schedule_interval="@once",
         catchup=False) as dag:

    create_bucket = S3CreateBucketOperator(
        task_id="create_s3_bucket",
        bucket_name="my-airflow-demo-bucket-123456",
        aws_conn_id="aws_default"
    )
